import java.io.*;
import java.util.Scanner;
import java.lang.Runtime;
import java.util.Random;

public class cpu
{
    static int interval = -1; //How many instructions to execute before the interrupt starts (maximum timer value)
    static int PC = 0, SP = 1000, IR = 0, AC = 0, X = 0, Y = 0, timer = 0;
    static boolean userMode = true;
    static boolean interrupts = true;
    static final int systemStackStart = 2000;

    public static void startInterrupt(PrintWriter printwriter, Scanner scanner)
    {
	userMode = false;
	interrupts = false;
	printwriter.println(1);
	printwriter.println(systemStackStart - 1);
	printwriter.println(SP);
	printwriter.flush();
	if (scanner.hasNext()) //Verify Write                                                                                                                                            
	    {
		int read = scanner.nextInt(); //Reading from memory                                                                                                                     
		if (read != -1)
		    {
			System.exit(0);
		    }
	    }
	printwriter.println(1);
	printwriter.println(systemStackStart - 2);
	printwriter.println(PC);
	printwriter.flush();
	if (scanner.hasNext()) //Verify Write                                                                                                                                           
	    {
		int read = scanner.nextInt(); //Reading from memory                                                                                                                     
		if (read != -1)
		    {
			System.exit(0);
		    }
	    }
	SP = systemStackStart - 2;
	PC = 1000;

    }
    
    public static void run(InputStream readFromMemory, OutputStream writeToMemory)
    {
        PrintWriter printwriter = new PrintWriter(writeToMemory);
        Scanner scanner = new Scanner(readFromMemory);
        while (true)
	    {
		printwriter.println(0); //Fetch Instruction
		printwriter.println(PC);
		printwriter.flush();
		if (scanner.hasNext()) //Reading
		    {
			IR = scanner.nextInt(); //Store inside IR
			PC++;
			instructions(printwriter, scanner); //Executing the instructions function
			timer++;
			if (timer == interval)
			    {
				timer = 0;
				if (interrupts && IR != 30)
				    {
					startInterrupt(printwriter, scanner);
				    }
			    }	
		    }
	    }
    }

    public static void instructions(PrintWriter printwriter, Scanner scanner)
    {
        if (IR == 1) //Load the value into the AC
	    {
		printwriter.println(0); //Signalling a read to CPU
		printwriter.println(PC);
		printwriter.flush();
		if (scanner.hasNext()) //Reading
		    {
			AC = scanner.nextInt(); //Store inside AC
			PC++;
		    }
	    }
        else if (IR == 2) //Load the value at the address into the AC
	    {
		printwriter.println(0); //Signalling a read to CPU
		printwriter.println(PC);
		printwriter.flush();
		if (scanner.hasNext()) //Reading
		    {
			int address = scanner.nextInt(); //Store inside IR
			PC++;
			if (userMode && address > 999)
			    {
				System.out.println("Memory Violation at: " + address);
				System.exit(0);
			    }
			printwriter.println(0); //Signalling a read to CPU
			printwriter.println(address);
			printwriter.flush();
			if (scanner.hasNext())
			    {
				AC = scanner.nextInt();
			    }
		    }
	    }
        else if (IR == 3) //Load the value from the address found in the given address into the AC
	    {
		printwriter.println(0); //Signalling a read to CPU
		printwriter.println(PC);
		printwriter.flush();
		if (scanner.hasNext())
		    {
			int address = scanner.nextInt(); //Store inside IR
			PC++;
			if (userMode && address > 999)
			    {
                                System.out.println("Memory Violation at: "+ address);
				System.exit(0);
			    }
			printwriter.println(0); //Signalling a read to CPU
			printwriter.println(address);
			printwriter.flush();
			if (scanner.hasNext())
			    {
				int address1 = scanner.nextInt();
				if (userMode && address1 > 999)
				    {
					System.exit(0);
				    }
				printwriter.println(0); //Signalling a read to CPU
				printwriter.println(address1);
				printwriter.flush();
				if (scanner.hasNext())
				    {
					AC = scanner.nextInt();
				    }
			    }
		    }
	    }
	else if (IR == 4) //Load the value at (address+X) into the AC
            {
                printwriter.println(0); //Signalling a read to CPU
                printwriter.println(PC);
		printwriter.flush();
                if (scanner.hasNext()) //Reading                                               
                    {
                        int address = scanner.nextInt(); //Store inside IR                      
                        PC++;
                        if (userMode && (address + X) > 999)
                            {
				System.exit(0);
                            }
                        printwriter.println(0); //Signalling a read to CPU
                        printwriter.println(address + X);
			printwriter.flush();
                        if (scanner.hasNext())
                            {
                                AC = scanner.nextInt();
                            }
                    }
            }
	else if (IR == 5) //Load the value at (address+Y) into the AC
            {
                printwriter.println(0); //Signalling a read to CPU                             
                printwriter.println(PC);
		printwriter.flush();
                if (scanner.hasNext()) //Reading
		    {
                        int address = scanner.nextInt(); //Store inside IR
			PC++;
                        if (userMode && (address + Y) > 999)
                            {
				System.exit(0);
                            }
                        printwriter.println(0); //Signalling a read to CPU                     
                        printwriter.println(address + Y);
			printwriter.flush();
                        if (scanner.hasNext())
                            {
                                AC = scanner.nextInt();
                            }
                    }
            }
	else if (IR == 6) //Load from (Sp+X) into the AC (if SP is 990, and X is 1, load from 991).
            {
		int address = SP + X;
		if (userMode && address > 999)
		    {
			System.exit(0);
		    }
		printwriter.println(0); //Signalling a read to CPU                                                                                                                     
		printwriter.println(address);
		printwriter.flush();
		if (scanner.hasNext())
		    {
			AC = scanner.nextInt();
		    }
	    }
	else if (IR == 7) //Store the value in the AC into the address
            {
		printwriter.println(0); //Signalling a read to CPU
		printwriter.println(PC);
		printwriter.flush();
		if (scanner.hasNext()) //Reading                                                                                                                                               
                    {
                        int address = scanner.nextInt();
			PC++;
			if (userMode && address > 999)
                            {
				System.exit(0);
                            }
			printwriter.println(1); //Signalling a write to CPU                                                                                                                     
                        printwriter.println(address);
			printwriter.println(AC);
			printwriter.flush();
                        if (scanner.hasNext())
                            {
				int read = scanner.nextInt(); //Reading from memory
				if (read != -1)
				    {
					System.exit(0);
				    }
                            }
                    }
            }
	else if (IR == 8) //Gets a random int from 1 to 100 into the AC
            {
		Random random = new Random();
		AC = random.nextInt(100) + 1;
	    }
    	else if (IR == 9) //If port=1, writes AC as an int to the screen, If port=2, writes AC as a char to the screen
	    {
		printwriter.println(0); //Signalling a read to CPU                                                                                                                              
                printwriter.println(PC);
		printwriter.flush();
		if (scanner.hasNext())
		    {
			PC++;
			int port = scanner.nextInt();
			if (port == 1)
			    {
				System.out.print(AC);
			    }		    
			else if (port == 2)
			    {
				System.out.print((char)AC);
			    }
		    }
	    }
    	else if (IR == 10) //Add the value in X to the AC
	    {
		AC = AC + X;
	    }
	else if (IR == 11) //Add the value in Y to the AC                                                                                                                                       
            {
		AC = AC + Y;
            }
	else if (IR == 12) //Subtract the value in X from the AC
            {
		AC = AC - X;
            }
	else if (IR == 13) //Subtract the value in Y from the AC                                                                                                                                
            {
		AC = AC - Y;
            }
	else if (IR == 14) //Copy the value in the AC to X
            {
		X = AC;
            }
	else if (IR == 15) //Copy the value in X to the AC
            {
		AC = X;
            }
	else if (IR == 16) //Copy the value in the AC to Y                                                                                                                                      
            {
		Y = AC;
            }
        else if (IR == 17) //Copy the value in Y to the AC                                                                                                                                      
            {
		AC = Y;
            }
	else if (IR == 18) //Copy the value in AC to the SP
            {
		SP = AC;
            }
	else if (IR == 19) //Copy the value in SP to the AC 
            {
		AC = SP;
            }
	else if (IR == 20) //Jump to the address
            {
		printwriter.println(0); //Signalling a read to CPU                                                                                                                              
                printwriter.println(PC);
		printwriter.flush();
		if (scanner.hasNext()) //Reading                                                                                                                                                
                    {
                        PC++;
			int address = scanner.nextInt();                
			PC = address;
                    }
            }
	else if (IR == 21) //Jump to the address only if the value in the AC is zero
	    {
		printwriter.println(0); //Signalling a read to CPU                                                                                                                              
                printwriter.println(PC);
		printwriter.flush();
                if (scanner.hasNext()) //Reading                                                                                                                                                
                    {
                        PC++;
                        int address = scanner.nextInt();
			if (AC == 0)
			    {
				PC = address;
			    }
		    }
            }
	else if (IR == 22) //Jump to the address only if the value in the AC is not zero
            {
                printwriter.println(0); //Signalling a read to CPU                                                                                                                              
                printwriter.println(PC);
		printwriter.flush();
                if (scanner.hasNext()) //Reading                                                                                                                                                
                    {
                        PC++;
                        int address = scanner.nextInt();
                        if (AC != 0)
                            {
                                PC = address;
                            }
                    }
            }
	else if (IR == 23) //Push return address onto stack, jump to the address
            {
                printwriter.println(0); //Signalling a read to CPU                                                                                                                              
                printwriter.println(PC);
		printwriter.flush();
                if (scanner.hasNext()) //Reading                                                                                                                                                
                    {
			PC++;
			int address = scanner.nextInt(); //Get arguments        
			SP--;
			printwriter.println(1); //Signalling a write to CPU                                                                                                                     
                        printwriter.println(SP);
                        printwriter.println(PC);
			printwriter.flush();
                        if (scanner.hasNext())
                            {
                                int read = scanner.nextInt(); //Reading from memory                                                                                                             
                                if (read != -1)
                                    {
                                        System.exit(0);
                                    }
                            }
			PC = address;
                    }
            }
	else if (IR == 24) //Pop return address from the stack, jump to the address
            {
		printwriter.println(0); //Signalling a read to CPU                                                                                                                              
                printwriter.println(SP);
		printwriter.flush();
                if (scanner.hasNext()) //Reading                                                                                                                                                
                    {
                        PC = scanner.nextInt();
                        SP++;
                    }
            }
	else if (IR == 25) //Increment the value in X
            {
		X++;
            }
	else if (IR == 26) //Decrement the value in X
            {
		X--;
            }
	else if (IR == 27) //Push AC onto stack                                                                                                                                                 
            {
		SP--;
		printwriter.println(1); //Signalling a write to CPU                                                                                                                     
		printwriter.println(SP);
		printwriter.println(AC);
		printwriter.flush();
		if (scanner.hasNext())
		    {
			int read = scanner.nextInt(); //Reading from memory                                                                                                             
			if (read != -1)
			    {
				System.exit(0);
			    }
		    }
	    }
	else if (IR == 28) //Pop from stack into AC
            {
                printwriter.println(0); //Signalling a read to CPU                                                                                                                              
                printwriter.println(SP);
		printwriter.flush();
                if (scanner.hasNext()) //Reading                                                                                                                                                
                    {
                        AC = scanner.nextInt();
                        SP++;
                    }
            }
	else if (IR == 29) //Perform system call
	    {
		userMode = false;
		interrupts = false;
		printwriter.println(1);
		printwriter.println(systemStackStart - 1);
		printwriter.println(SP);
		printwriter.flush();
		if (scanner.hasNext()) //Verify Write
                    {
                        int read = scanner.nextInt(); //Reading from memory                                                                                                                     
                        if (read != -1)
                            {
                                System.exit(0);
                            }
                    }
                printwriter.println(1);
                printwriter.println(systemStackStart - 2);
		printwriter.println(PC);
		printwriter.flush();
		if (scanner.hasNext()) //Verify Write                                                                                                                                           
                    {
                        int read = scanner.nextInt(); //Reading from memory                                                                                                                     
                        if (read != -1)
                            {
                                System.exit(0);
                            }
                    }
		SP = systemStackStart - 2;
		PC = 1500;
	    }
       	else if (IR == 30) //Return from system call
	    {
		userMode = true;
		interrupts = true;
		printwriter.println(0);
		printwriter.println(SP);
		printwriter.flush();
		if (scanner.hasNext())
		    {
			PC = scanner.nextInt();
			SP++;
			printwriter.println(0);
			printwriter.println(SP);
			printwriter.flush();
			if (scanner.hasNext())
			    {
				SP = scanner.nextInt();
			    }
		    }
	    }
	else if (IR == 50) //End execution
	    {
                printwriter.println(-1);
		printwriter.close();
                scanner.close();
		System.exit(0); //CPU exits
	    }
    }
    public static void main (String args[])
    {
        if (args.length != 2) //Check argument count
	    {
		System.err.println("Error");
		System.exit(0);
	    }
	try
	    {
		interval = Integer.parseInt(args[1]);
		if (interval <= 0)
		    {
			System.err.println("Error, no interval given");
			System.exit(0);
		    }
 
		int x;
		Runtime rt = Runtime.getRuntime();
		
		Process proc = rt.exec("java memory " + args[0]); //Executes the text file given in command line
		
		InputStream readFromMemory = proc.getInputStream(); //Reading from memory
		OutputStream writeToMemory = proc.getOutputStream(); //Writing to memory
		
		run(readFromMemory, writeToMemory); //calling run function
		//PrintWriter pw = new PrintWriter(os);
		//pw.printf("Greg\n");
		//pw.flush();
		
		//Scanner sc = new Scanner(is);
		
		//String line = sc.nextLine();
		
		proc.waitFor();
		
		int exitVal = proc.exitValue();
		
		System.out.println("Process exited: " + exitVal);
		
	    }
        catch (Throwable t)
	    {
		t.printStackTrace();
	    }

    }
}
