import java.util.Scanner;
import java.io.IOException;
import java.util.List;
import java.io.File;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class memory
{
    final static int[] array = new int[2000]; // 2000 Initializing array
    public static int read (int address)
    {
	if (address >= 0 && address <= 1999)
	    {
		return array[address];
	    }
	else 
	    {
		throw new IndexOutOfBoundsException();
	    }
    }
    
    public static void write (int address, int data)
    {
	if (address >= 0 && address <= 1999)
            {
		array[address] = data;
            }
        else
            {
		throw new IndexOutOfBoundsException();
            }
    }
    
    public static void run()
    {
	Scanner inputStream = new Scanner(System.in);
	while (inputStream.hasNext())
	    {
		System.err.println("TEST");
		int command = inputStream.nextInt();
		if (command == 0)
		    {
			int readAddress = inputStream.nextInt(); //Gets address from CPU
			int returnData = read(readAddress); //Accessing memory and stores it
			System.out.println(returnData); //Sending to CPU
		    }
		else if (command == 1)
		    {
			int writeAddress = inputStream.nextInt();
			int writeData = inputStream.nextInt();
			write(writeAddress, writeData); //calls write function
			System.out.println(-1);
		    }	    
		else if (command == -1) //Exits memory
		    {
			System.exit(0);
		    }
	    }
	inputStream.close();    
    }

    public static void main(String args[])
    {
	try
	    {
		File myFile = new File(args[0]);
		Scanner scanner = new Scanner(myFile);
		Pattern regex = Pattern.compile("\\d+");
		int i = 0;
		int removeDot;
		boolean flag = true;
		
		//String name = null;
		while (scanner.hasNextLine())
		    {
			//Array
			String test = scanner.nextLine(); //Reads each line from text file
			if (test.equals(""))
			    {
				continue;			    
			    }
			Matcher matcher = regex.matcher(test); //Creates pattern matcher object                                                                                          
			if (test.charAt(0) == '.') //Looks for .
			    {
				//System.out.println(test);
				if (matcher.find()) 
				    {
					String match = matcher.group(0); //Matches regex
					i = Integer.parseInt(match);
				    }
				continue;
			    }
			if (matcher.find()) //Looks for #
			    {
				String match = matcher.group(0); //Matches regex                                                                                                         
				int array1 = Integer.parseInt(match);
				array[i] = array1;
				i++;
			    }
		    }
	        scanner.close();
		run();
	    }    
	catch(Throwable e)
	    {
		//System.out.println("An error occurred!");
		e.printStackTrace();		
	    }
	//System.out.print(Arrays.toString(array)); //Prints out array
 
   }
}
